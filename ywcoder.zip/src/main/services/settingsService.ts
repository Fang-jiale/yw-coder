import { Settings } from '../../shared/types';
import * as fs from 'fs/promises';
import { readFileSync } from 'fs';
import * as path from 'path';
import { app } from 'electron';

const defaultSettings: Settings = {
  theme: 'light',
  fontSize: 14,
  fontFamily: 'JetBrains Mono, Fira Code, Consolas, monospace',
  tabSize: 2,
  wordWrap: true,
  minimap: true,
  aiProvider: 'openai',
  aiModel: 'gpt-4',
  aiApiKey: '',
  language: 'zh-CN',
};

export class SettingsService {
  private configPath: string;
  private settings: Settings;
  private loaded: boolean = false;

  constructor() {
    // 使用 userData 目录存储配置（跨平台，开发和生产一致）
    const userData = app.getPath('userData');
    this.configPath = path.join(userData, 'config', 'settings.json');
    this.settings = { ...defaultSettings };
    // 同步加载设置
    this.loadSettingsSync();
  }

  private loadSettingsSync(): void {
    try {
      const data = readFileSync(this.configPath, 'utf-8');
      this.settings = { ...defaultSettings, ...JSON.parse(data) };
      this.loaded = true;
    } catch {
      // 文件不存在或读取失败，使用默认设置
      this.settings = { ...defaultSettings };
      this.loaded = true;
    }
  }

  private async saveSettings(): Promise<void> {
    try {
      await fs.mkdir(path.dirname(this.configPath), { recursive: true });
      await fs.writeFile(this.configPath, JSON.stringify(this.settings, null, 2), 'utf-8');
    } catch (error) {
      console.error('Failed to save settings:', error);
    }
  }

  get(key?: string): any {
    if (key) {
      return this.settings[key as keyof Settings];
    }
    return this.settings;
  }

  set(key: string, value: any): void {
    (this.settings as any)[key] = value;
    this.saveSettings();
  }

  getAll(): Settings {
    return this.settings;
  }

  reset(): void {
    this.settings = { ...defaultSettings };
    this.saveSettings();
  }
}
