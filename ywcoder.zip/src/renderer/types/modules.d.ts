declare module 'react-syntax-highlighter' {
  import { ComponentType } from 'react';
  
  interface SyntaxHighlighterProps {
    language?: string;
    style?: any;
    children?: string;
    PreTag?: string | ComponentType<any>;
    [key: string]: any;
  }
  
  export const Prism: ComponentType<SyntaxHighlighterProps>;
  export const Light: ComponentType<SyntaxHighlighterProps>;
}

declare module 'react-syntax-highlighter/dist/esm/styles/prism' {
  export const vscDarkPlus: any;
  export const vs: any;
  export const dark: any;
  export const okaidia: any;
  export const prism: any;
  export const tomorrow: any;
  export const twilight: any;
}

declare module 'react-syntax-highlighter/dist/cjs/styles/prism' {
  export const vscDarkPlus: any;
  export const vs: any;
  export const dark: any;
  export const okaidia: any;
  export const prism: any;
  export const tomorrow: any;
  export const twilight: any;
}
